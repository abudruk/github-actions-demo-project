ALLOWED_XUI_EXTENSIONS = [".py", ".md", ".html"]
